function findAccountById(accounts, id) {
    return accounts.find((account) => account.id === id);
}

function sortAccountsByLastName(accounts) {
   return accounts.sort((firstAccount, secondAccount) => {
    const firstLastName = firstAccount.name.last;
    const secondLastName = secondAccount.name.last;
    return firstLastName.toLowerCase() < secondLastName.toLowerCase() ? -1 : 1;
  });
}

function getTotalNumberOfBorrows(account, books) {
   const { id } = account;
  let total = 0;

  for (let book in books) {
    const { borrows } = books[book];
    borrows.forEach((element) => {
      return element.id===id ? total++ : total
    });
  }

  return total;
}


function getBooksPossessedByAccount(account, books, authors) {
 let booksPossessed=[];
 
  books.forEach(book => {
    let borrowArray = book.borrows;
    return borrowArray.find(borrow => borrow.id === account.id && borrow.returned === false) ?  booksPossessed.push(book) : book
    }
  )
  
  booksPossessed.forEach(book=>{
    let author = authors.find(person => person.id === book.authorId);
    book['author'] = author;
  })
 
  return booksPossessed;
}


module.exports = {
  findAccountById,
  sortAccountsByLastName,
  getTotalNumberOfBorrows,
  getBooksPossessedByAccount,
};
