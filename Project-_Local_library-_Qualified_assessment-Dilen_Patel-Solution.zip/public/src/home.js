function getTotalBooksCount(books) {
  return books.length;
}

function getTotalAccountsCount(accounts) {
  return accounts.length;
}

function getBooksBorrowedCount(books) {
   let total = 0;
  books.forEach((book) => {
    return !book.borrows[0].returned ?  total++ : total
  });

  return total;
}


function getMostCommonGenres(books) {
   const genresOfBooks = books.map((book) => book.genre);
    const commonGenres = [];

  genresOfBooks.map((genre) => {
 
      const genreLocation = commonGenres.findIndex((genrePart) => genrePart.name === genre);
     return genreLocation >= 0 ? commonGenres[genreLocation].count = commonGenres[genreLocation].count + 1 : commonGenres.push({ name: genre, count: 1 })
    });
    commonGenres.sort((a, b) => b.count - a.count);
  return commonGenres.length > 5 ? commonGenres.slice(0, 5): commonGenres
  return commonGenres;
}

function getMostPopularBooks(books) {
 const result = books.map((book) => {
    const popularity = {
      name: book.title,
      count: book.borrows.length,
    };

    return popularity;
  });

  // sort the new array by count: greatest to least
  result.sort((titleA, titleB) => titleB.count - titleA.count);

  // limit to 5 elements
  result.splice(5);

  return result;
}

function getMostPopularAuthors(books, authors) {
  const getBooksByAuthorId = (books, authorId) => {
  return books.filter((book) => book.authorId === authorId);
};
  const result = authors.map((author) => {
    const fullName = `${author.name.first} ${author.name.last}`;
    const booksByAuthor = getBooksByAuthorId(books, author.id);
    const totalBorrows = booksByAuthor.reduce((accum, book) => accum + book.borrows.length, 0);
    const newAuthorInfo = {
      name: fullName,
      count: totalBorrows,
    };

    return newAuthorInfo;
  });

  
  result.sort((authorA, authorB) => authorB.count - authorA.count);

  
  result.splice(5);

  return result;
}


module.exports = {
  getTotalBooksCount,
  getTotalAccountsCount,
  getBooksBorrowedCount,
  getMostCommonGenres,
  getMostPopularBooks,
  getMostPopularAuthors,
};
